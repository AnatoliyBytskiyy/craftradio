<div class="header">
    <div class="container">
      <div class="header__body">
        <div class="header__logo">
          <img src="./img/header/logo.png" alt="Logo">
        </div>
        <div class="header__text">
          <h3 class="header__heading">Производитель оборудования для</h3>
          <h3 class="header__heading">Профессионального радиовещания</h3>
        </div>
        <div class="header__call">
          <span class="header__time">Время  работы:  с  10-00  до  19-00</span>
          <span class="header__number">+7(495) 228-17-27</span>
          <button class="header__btn"><img class="header__image" src="./img/header/phone.png" alt="Phone">заказать звонок</button>
        </div>
      </div>
    </div>
  </div>