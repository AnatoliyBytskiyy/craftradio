<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="./css/normalize.css">
<link rel="stylesheet" href="./css/main.css">
<link rel="stylesheet" href="./css/product.css">
<title>Товар</title>
</head>
<body>
  <?php
    include('./header__mobile.php');
  ?>

  <?php
    include('./nav.php');
  ?>
  
  <?php
    include('./header.php');
  ?>

  <main class="product">
    <div class="container">
      <div class="product__body">
        <div class="product__block">
          <div class="product__images">
            <div class="product__image">
              <h1 class="product__heading product__heading_mob">транслятор аудио потоков</h1>
              <img name="image" class="product__img" src="./img/product/image1.png" alt="Image 1">
            </div>
            <div class="product__preview">
              <div class="product__row">
                <a href="javascript:l_image ('./img/product/image1.png')"><img class="product__img-prv" src="./img/product/image1.png" alt="Image 2"></a>
                <a href="javascript:l_image ('./img/product/image1.png')"><img class="product__img-prv" src="./img/product/image1.png" alt="Image 3"></a>
                <a href="javascript:l_image ('./img/product/image1.png')"><img class="product__img-prv" src="./img/product/image1.png" alt="Image 4"></a>
              </div>
              <div class="product__row">
                <a href="javascript:l_image ('./img/product/image1.png')"><img class="product__img-prv" src="./img/product/image1.png" alt="Image 5"></a>
                <a href="javascript:l_image ('./img/product/image1.png')"><img class="product__img-prv product__mob" src="./img/product/image1.png" alt="Image 5"></a>
                <div class="product__video">
                  <a href="javascript:l_image ('./img/product/image1.png')"><img src="./img/product/play.png" alt="Video"></a>
                </div>
              </div>
            </div>
          </div>
          <div class="product__info">
            <h1 class="product__heading">транслятор аудио потоков</h1>
            <div class="product__featuers">
              <div class="product__icons">
                <img class="product__img product__mobile" src="./img/product/icon1.png" alt="Icon 1">
                <img class="product__img"src="./img/product/icon2.png" alt="Icon 2">
                <img class="product__img" src="./img/product/icon3.png" alt="Icon 3">
                <img class="product__img" src="./img/product/icon4.png" alt="Icon 4">
              </div>
              <div class="product__features-1">
                <p class="product__mobile">Бесплатная доставка:</p><br>
                <p>Гарантия:</p><br>
                <p>Настройка:</p><br>
                <p>Бесплатная поддержка:</p><br>
              </div>
              <div class="product__features-2">
                <p class="product__feature_bold product__mobile">19.12.19</p><br>
                <p class="product__feature_bold">1 год</p><br>
                <p class="product__feature_bold">Бесплатно</p><br>
                <p class="product__feature_bold">1 год</p><br>
              </div>
            </div>
            <div class="product__footer">
              <div>
                <span class="product__feature_bold">Цена:</span>
                <span class="product__number">54 698</span>
                <span class="product__feature_bold">руб.</span>
              </div>
              <button class="product__btn">купить</button>
            </div>
          </div>
        </div>
        <div class="product__tabs">
          <input type="radio" name="odin" checked="checked" id="vkl1"/><label for="vkl1">Описание</label><input type="radio" name="odin" id="vkl2"/><label for="vkl2">Характеристики</label><input type="radio" name="odin" id="vkl3"/><label for="vkl3">Инструкции</label>
          <div class="product__descript">
            <p>Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях, профилактике и авариях транслятор резервирует пропадание сигнала. Если вещательный комплекс "завис", или необходимо снять компьютер, транслятор считает что сигнала нет, и включит поток автоматически по заданному параметру непосредственно на передатчик.</p><br>
            <p>Транслятор может делать врезки в эфир. Для этого нужно прописать сигнальный поток в настройках. При появлении звукового сигнала по заданному времени транслятор начнёт передавать ваш сигнальный поток. После окончания передачи, когда диджей в студии сделает заданную паузу транслятор сам перейдёт на вещание потока или спутника.</p><br>
            <p>Для решения проблемы «последеней мили»вы можете установить транслятор в стойку с передатчком, а свою программу запустить на свой сервер по протоколу Ice cast.</p><br>
            <span class="product__feature_bold">Удобен для звукового вещания:</span>
            <ul><br>
              <li>на улицах города</li>
              <li>парках</li>
              <li>торговых центрах</li>
              <li>оповещении при ЧС</li>
            </ul><br>
            <span class="product__feature_bold">Настроив на сервере нужные потоки для каждой зоны, вы принимаете каждый поток на отдельное устройство.</span>
          </div>
          <div class="product__chars">
            <p>Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях, профилактике и авариях транслятор резервирует пропадание сигнала. Если вещательный комплекс "завис", или необходимо снять компьютер, транслятор считает что сигнала нет, и включит поток автоматически по заданному параметру непосредственно на передатчик.</p><br>
            <p>Транслятор может делать врезки в эфир. Для этого нужно прописать сигнальный поток в настройках. При появлении звукового сигнала по заданному времени транслятор начнёт передавать ваш сигнальный поток. После окончания передачи, когда диджей в студии сделает заданную паузу транслятор сам перейдёт на вещание потока или спутника.</p><br>
            <p>Для решения проблемы «последеней мили»вы можете установить транслятор в стойку с передатчком, а свою программу запустить на свой сервер по протоколу Ice cast.</p><br>
            <span class="product__feature_bold">Удобен для звукового вещания:</span>
            <ul><br>
              <li>на улицах города</li>
              <li>парках</li>
              <li>торговых центрах</li>
              <li>оповещении при ЧС</li>
            </ul><br>
            <span class="product__feature_bold">Настроив на сервере нужные потоки для каждой зоны, вы принимаете каждый поток на отдельное устройство.</span>
          </div>
          <div class="product__instruct">
            <p>Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях, профилактике и авариях транслятор резервирует пропадание сигнала. Если вещательный комплекс "завис", или необходимо снять компьютер, транслятор считает что сигнала нет, и включит поток автоматически по заданному параметру непосредственно на передатчик.</p><br>
            <p>Транслятор может делать врезки в эфир. Для этого нужно прописать сигнальный поток в настройках. При появлении звукового сигнала по заданному времени транслятор начнёт передавать ваш сигнальный поток. После окончания передачи, когда диджей в студии сделает заданную паузу транслятор сам перейдёт на вещание потока или спутника.</p><br>
            <p>Для решения проблемы «последеней мили»вы можете установить транслятор в стойку с передатчком, а свою программу запустить на свой сервер по протоколу Ice cast.</p><br>
            <span class="product__feature_bold">Удобен для звукового вещания:</span>
            <ul><br>
              <li>на улицах города</li>
              <li>парках</li>
              <li>торговых центрах</li>
              <li>оповещении при ЧС</li>
            </ul><br>
            <span class="product__feature_bold">Настроив на сервере нужные потоки для каждой зоны, вы принимаете каждый поток на отдельное устройство.</span>
          </div>
        </div>
      </div>
    </div>
  </main>

  <?php
    include('./footer.php');
  ?>

  <!-- Scripts -->
  
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
  crossorigin="anonymous"></script>
  <script src="./js/main.js"></script>
  <script src="./js/gallery.js"></script>
</body>
</html>