<div class="header__mobile">
    <span class="header__time">Время  работы:  с  10-00  до  19-00</span>
    <span class="header__number">+7(495) 228-17-27</span>
    <button class="header__btn"><img class="header__image" src="./img/header/phone.png" alt="Phone">заказать звонок</button>
  </div>