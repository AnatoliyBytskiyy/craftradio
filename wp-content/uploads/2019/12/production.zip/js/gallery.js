function l_image (a) {
    document.image.src = a;
}