<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="./css/normalize.css">
<link rel="stylesheet" href="./css/main.css">
<link rel="stylesheet" href="./css/catalog.css">
<title>Каталог</title>
</head>
<body>
  <?php
    include('./header__mobile.php');
  ?>

  <?php
    include('./nav.php');
  ?>
  
  <?php
    include('./header.php');
  ?>

  <main class="catalog">
    <div class="container">
      <div class="catalog__body">
        <div class="text catalog__text">
          <h1 class="heading catalog__heading">оборудование для радиостанции</h1>
          <p class="article catalog__article">Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях, профилактике и авариях транслятор резервирует пропадание сигнала. Если вещательный комплекс "завис", или необходимо снять компьютер, транслятор считает что сигнала нет, и включит поток автоматически по заданному параметру непосредственно на передатчик.</p>
        </div>
        <div class="catalog__row">
          <div class="catalog__wrapper">
            <div class="block catalog__block">
              <img src="./img/catalog/image1.png" alt="Image 1">
              <div class="text block__text">
                <h2 class="heading block__heading">Транслятор потока</h2>
                <p class="article block__article">Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях.</p>
              </div>
              <div class="block__footer">
                <div class="block__price">
                  <span class="block__currency">Цена:</span>
                  <span class="block__numbers">54 698</span>
                  <span class="block__currency">руб.</span>
                </div>
                <button class="block__btn">купить</button>
              </div>
            </div>
            <div class="block catalog__block">
              <img src="./img/catalog/image1.png" alt="Image 2">
              <div class="text block__text">
                <h2 class="heading block__heading">Транслятор потока</h2>
                <p class="article block__article">Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях.</p>
              </div>
              <div class="block__footer">
                <div class="block__price">
                  <span class="block__currency">Цена:</span>
                  <span class="block__numbers">54 698</span>
                  <span class="block__currency">руб.</span>
                </div>
                <button class="block__btn">купить</button>
              </div>
            </div>
          </div>
          <div class="catalog__wrapper">
            <div class="block catalog__block">
              <img src="./img/catalog/image1.png" alt="Image 3">
              <div class="text block__text">
                <h2 class="heading block__heading">Транслятор потока</h2>
                <p class="article block__article">Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях.</p>
              </div>
              <div class="block__footer">
                <div class="block__price">
                  <span class="block__currency">Цена:</span>
                  <span class="block__numbers">54 698</span>
                  <span class="block__currency">руб.</span>
                </div>
                <button class="block__btn">купить</button>
              </div>
            </div>
            <div class="block catalog__block">
              <img src="./img/catalog/image1.png" alt="Image 4">
              <div class="text block__text">
                <h2 class="heading block__heading">Транслятор потока</h2>
                <p class="article block__article">Устройство решает проблему подачи аудио сигнала и резервирования его там, где нет возможности установить приёмную спутниковую антенну или это дорого. При плохих погодных условиях.</p>
              </div>
              <div class="block__footer">
                <div class="block__price">
                  <span class="block__currency">Цена:</span>
                  <span class="block__numbers">54 698</span>
                  <span class="block__currency">руб.</span>
                </div>
                <button class="block__btn">купить</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <?php
    include('./footer.php');
  ?>

  <!-- Scripts -->
  
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
  crossorigin="anonymous"></script>
  <script src="./js/main.js"></script>
</body>
</html>