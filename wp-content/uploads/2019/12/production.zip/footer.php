<footer class="footer">
    <div class="container">
      <div class="footer__body">
        <div class="footer__menu">
          <div>
            <a href="#" class="footer__link">Главная</a>
            <a href="#" class="footer__link">О компании</a>
          </div>
          <div>
            <a href="#" class="footer__link">Оборудование</a>
            <a href="#" class="footer__link">Оплата и доставка</a>
          </div>
          <a href="#" class="footer__link">Контакты</a>
        </div>
        <div class="footer__rights">
          <div class="footer__text">
            <span>2014-2019 ООО "craftradio.ru".</span>
            <span>Все права защищены.</span>
          </div>
          <a href="#">Политика конфидециальности</a>
        </div>
      </div>
    </div>
  </footer>