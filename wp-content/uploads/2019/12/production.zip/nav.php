</div>
  <nav class="nav">
    <div class="container">
      <div class="nav__body">
        <div class="nav__menu">
          <div class="nav__burger">
            <span class="nav__inner"></span>
          </div>
          <div class="nav__links">
            <ul class="nav__list">
              <li>
                <a class="nav__link" href="#" class="nav__link">Главная</a>
              </li>
              <li>
                <a class="nav__link" href="#" class="nav__link">О компании</a>
              </li>
              <li>
                <a class="nav__link" href="#" class="nav__link">Оборудование</a>
              </li>
              <li>
                <a class="nav__link" href="#" class="nav__link">Оплата и доставка</a>
              </li>
              <li>
                <a class="nav__link" href="#" class="nav__link">Контакты</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="nav__address">
          <span>г. Москва, ул. Шаболовка, д. 34</span>
        </div>
      </div>
    </div>
  </nav>