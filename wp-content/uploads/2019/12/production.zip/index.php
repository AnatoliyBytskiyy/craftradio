<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="./css/normalize.css">
<link rel="stylesheet" href="./css/main.css">
<link rel="stylesheet" href="./css/home.css">
<title>Главная</title>
</head>
<body>
  <?php
    include('./header__mobile.php');
  ?>

  <?php
    include('./nav.php');
  ?>
  
  <?php
    include('./header.php');
  ?>

  <main class="main">
    <div class="container">
      <div class="main__body">
        <div>
          <img src="./img/main/image.png" alt="Radio" class="main__image">
          <img src="./img/main/image_mobile.png" alt="Radio" class="main__mobile">
        </div>
        <div>
          <p class="main__text">Более 20 лет мы работаем в радио<br> 
            индустрии, и решаем пробемы компаний<br> 
            которые занимаются радиовещанием.<br> 
            Расскажите нам детали своего проекта,<br>
            и мы поможем сэкономить время на<br>
            подбор оборудования, и предложим<br> 
            интересные условия</p>
          <button class="main__btn">заполнить опросник</button>
        </div>
      </div>
    </div>
  </main>

  <div class="slider">
    <div class="container">
      <div class="slider__body">
        <div class="slider__item slider__fade">
          <h2 class="slider__mobile">транслятор аудио потоков</h2>
          <img class="slider__image" src="./img/slider/slide_1.png" alt="Slide 1">
          <div class="slider__mobile-arrows">
            <a class="slider__prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="slider__next" onclick="plusSlides(1)">&#10095;</a>
          </div>
          <div class="slider__block">
            <h2 class="slider__heading">транслятор аудио потоков</h2>
            <p class="slider__text">Устройство решает проблему подачи аудио сигнала и резервирования его там, где<br> нет возможности установить приёмную спутниковую антенну или это дорого. При<br> плохих погодных условиях, профилактике и авариях транслятор резервирует<br> пропадание сигнала. Если вещательный комплекс "завис", или необходимо снять<br> компьютер, транслятор считает что сигнала нет, и включит поток автоматически по<br> заданному параметру непосредственно на передатчик.</p>
            <div class="slider__footer">
              <div>
                <span class="slider__price">54 698</span>
                <span class="slider__currency">руб.</span>
              </div>
              <button class="slider__btn">купить</button>
            </div>
          </div>
        </div>
        <div class="slider__item slider__fade">
          <h2 class="slider__mobile">транслятор аудио потоков</h2>
          <img class="slider__image" src="./img/slider/slide_1.png" alt="Slide 1">
          <div class="slider__mobile-arrows">
            <a class="slider__prev" onclick="plusSlides(-1)">&#10094</a>
            <a class="slider__next" onclick="plusSlides(1)">&#10095</a>
          </div>
          <div class="slider__block">
            <h2 class="slider__heading">транслятор аудио потоков</h2>
            <p class="slider__text">Устройство решает проблему подачи аудио сигнала и резервирования его там, где<br> нет возможности установить приёмную спутниковую антенну или это дорого. При<br> плохих погодных условиях, профилактике и авариях транслятор резервирует<br> пропадание сигнала. Если вещательный комплекс "завис", или необходимо снять<br> компьютер, транслятор считает что сигнала нет, и включит поток автоматически по<br> заданному параметру непосредственно на передатчик.</p>
            <div class="slider__footer">
              <div>
                <span class="slider__price">54 698</span>
                <span class="slider__currency">руб.</span>
              </div>
              <button class="slider__btn">купить</button>
            </div>
          </div>
        </div>
        <div class="slider__arrows">
          <a class="slider__prev" onclick="plusSlides(-1)">&#10094;</a>
          <a class="slider__next" onclick="plusSlides(1)">&#10095;</a>
        </div>
      </div>
    </div>
  </div>
  
  <?php
    include('./footer.php');
  ?>

  <!-- Scripts -->
  
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
  crossorigin="anonymous"></script>
  <script src="./js/main.js"></script>
  <script src="./js/slider.js"></script>
</body>
</html>